#ifndef DISPATCHER_H
#define DISPATCHER_H

void __attribute__ ((naked)) ctx_switch ( void );

#endif
